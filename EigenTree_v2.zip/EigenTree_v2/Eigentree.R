# NOTE
# command with "-" or "_" is not allowed in command matrix

setwd("./")
source('ToolFunc.r')
# Parameters
command = matrix(c("bfile","b",1,"character", "plink binary file prefix",
                   "autosome","a",1,"integer","autosome number for the population studied",
                   "population","p",1,"character","the population type, inbred or outbred, for the population studied",
                   "eigenspace","e",2,"integer", "the first top eigenvectors that about to be scanned, defaulted 5, maximum 10", 
                   "proportion","po",2,"double","samping a given proportion of markers to make a quick GRM and PCA, defaulted 1.0(100%)",
                   "maf","m",2,"double", "minor allele frequency, defaulted 0.03",
                   "help","h",0,"logical", "parameters input instruction"),
                 byrow=T,ncol=5)
args = getopt(spec = command)

if (!is.null(args$help) || is.null(args$bfile) || is.null(args$autosome)) {
  cat(paste(getopt(command, usage = T), "\n"))
  q()
}
# grab arguements
# force
bfile = args$bfile
autosome = args$autosome
population = args$population
# optional
eigenspace = 5
proportion = 1
maf = 0.05
plink = "plink"

if (!is.null(args$eigenspace)) {
  eigenspace = args$eigenspace
}
if (!is.null(args$proportion)) {
  proportion = args$proportion
}
if (!is.null(args$maf)) {
  maf = args$maf
}

cat(paste0("\nStarting process ", bfile, "...\nInput parameters:\nAutosome number: ", autosome, "\nPopulation type: ", population, "\nEigenspaces about to scan: ", eigenspace, "\nMarker samping proportion: ", proportion, "\nMAF: ", maf, "\n\n"))

# QC
# Extract autosome SNP variants
QC1 = paste0(plink, " --bfile ", bfile, " --chr-set ", autosome, " --allow-extra-chr --autosome --snps-only --make-bed --out ", bfile, ".1.autosome.snp")
# MAF and missing rate
QC2 = paste0(plink, " --bfile ", bfile, ".1.autosome.snp --chr-set ", autosome, " --maf ", maf, " --geno 0.2 --make-bed --out ", bfile, ".2.maf.geno")
# LD
QC3 = paste0(plink, " --bfile ", bfile, ".2.maf.geno --indep-pairwise 50 5 0.8 --out ", bfile, ".2.maf.geno.LD --chr-set ",autosome)
QC4 = paste0(plink, " --bfile ", bfile, ".2.maf.geno --extract ", bfile, ".2.maf.geno.LD.prune.in --make-bed --out ", bfile, ".3.core --chr-set ",autosome)


cat("QC...\nExtract autosome SNP variants...\n\n")
system(QC1)
cat("\nQC...\nMAF and missing rate...\n\n")
system(QC2)
cat("\nQC...\nLD pruning...\n\n")
system(QC3)
cat("\nQC...\nExtracting indep loci...\n\n")
system(QC4)

nn=as.numeric(strsplit(system(paste0("wc -l ", bfile, ".3.core.fam"),intern=T)," ")[[1]][1])
mm=as.numeric(strsplit(system(paste0("wc -l ", bfile, ".3.core.bim"),intern=T)," ")[[1]][1])
cat("\nQC finished! ",nn," samples and ",mm," SNPs remianed for EigenGWAS.\n\n")

frq_cmd = paste0(plink, " --bfile ", bfile, ".3.core --allow-extra-chr --allow-no-sex --autosome-num ",autosome," --freq --out ", bfile)
system(frq_cmd)

if(proportion==1){
  eigen_cmd = paste0(plink, " --bfile ", bfile, ".3.core --allow-extra-chr --allow-no-sex --autosome-num ",autosome, " --make-grm-gz --pca 10 --out ", bfile)
} else {
  eigen_cmd = paste0(plink, " --bfile ", bfile, ".3.core --allow-extra-chr --allow-no-sex --autosome-num ",autosome, " --make-grm-gz --pca 10 --thin ",proportion," --out ", bfile)
}
time1 = proc.time()
system(eigen_cmd)
time2 = proc.time()

Egvec = read.table(paste0(bfile,".eigenvec"),header = F)
write.table(Egvec[,c(1:(2+eigenspace))],paste0(bfile,".new.eigenvec"),quote=F,col.names = F,row.names = F)

scan_cmd = paste0(plink, " --allow-no-sex --allow-extra-chr --linear --bfile ", bfile, ".3.core --autosome-num ", autosome, " --pheno ", bfile, ".new.eigenvec --all-pheno --out ", bfile)
time3 = proc.time()
system(scan_cmd)
time4 = proc.time()

pop.info = Egvec[,c(1,2)]
for (i in 1:eigenspace){
  label = vector("numeric",length = length(Egvec))
  label[Egvec[,(2+i)]>0]=1
  label[Egvec[,(2+i)]<=0]=2
  pop.info=cbind(pop.info,label)
}
write.table(pop.info,"cluster.info",quote = F,col.names = F,row.names = F)

for(i in 1:eigenspace){
  fst_cmd = paste0(plink, " --bfile ", bfile, ".3.core --fst --autosome-num ",autosome, " --within cluster.info --mwithin ", i, " --out ", bfile, ".P", i)
  system(fst_cmd)
}

eigen_time = (time2-time1)[3][[1]]
scan_time = (time4-time3)[3][[1]]

isRunable = TRUE
if (!file.exists(paste0(bfile, ".eigenval"))) {
  isRunable = FALSE
} else if (!file.exists(paste0(bfile, ".frq"))) {
  isRunable = FALSE
} else if (!file.exists(paste0(bfile, ".eigenvec"))) {
  isRunable = FALSE
} else {
  for(i in 1:eigenspace) {
    if (!file.exists(paste0(bfile, ".P", i, ".assoc.linear"))) {
      isRunable = FALSE
    }
    if (!file.exists(paste0(bfile, ".P", i, ".fst"))) {
      isRunable = FALSE
    }
  }
}
if(args$population=="inbred"){
  sc = 2
}else if(args$population=="outbred"){
  sc = 1
}else{
  isRunable = FALSE
}
if(!isRunable) {
  stop("\nSome essential results are not generated yet.")
} else {
  params <- list(bfile = bfile,
                 proportion = proportion,
                 espace = eigenspace, 
                 sc = sc,
                 nn = nn,
                 mm = mm,
                 GRMT = eigen_time,
                 SCANT = scan_time)
  rmarkdown::render("egReport.Rmd", output_file = paste0(bfile,".EgRes.html"),params = params,envir = new.env(parent = globalenv()))
}
